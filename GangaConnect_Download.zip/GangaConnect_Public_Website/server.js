const express = require("express");
const Database = require("better-sqlite3");
const nodemailer = require("nodemailer");
const PDFDocument = require("pdfkit");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const crypto = require("crypto");
require("dotenv").config();

const app = express();
const db = new Database(process.env.DB_FILE || "gangaconnect.db");
const PORT = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "7mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 15 * 60 * 1000, limit: 100 }));

db.exec(`
CREATE TABLE IF NOT EXISTS reports (
  id TEXT PRIMARY KEY, reporter TEXT NOT NULL, email TEXT NOT NULL,
  location TEXT NOT NULL, issue TEXT NOT NULL, description TEXT NOT NULL,
  imageData TEXT, status TEXT NOT NULL DEFAULT 'Reported', createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS enrollments (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL,
  projectName TEXT NOT NULL, attended INTEGER NOT NULL DEFAULT 0,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS initiatives (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL,
  createdAt TEXT NOT NULL
);
`);

function mailer() {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE || "false") === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}
async function sendMail(to, subject, text) {
  const transport = mailer();
  if (!transport) {
    console.warn("Email not sent: configure SMTP_HOST, SMTP_USER and SMTP_PASS.");
    return false;
  }
  await transport.sendMail({ from: process.env.MAIL_FROM || process.env.SMTP_USER, to, subject, text });
  return true;
}
function makeId(prefix) {
  return prefix + "-" + crypto.randomBytes(4).toString("hex").toUpperCase();
}
function requireAdmin(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!process.env.ADMIN_TOKEN || token !== process.env.ADMIN_TOKEN) {
    return res.status(401).json({error: "Administrator authorization required."});
  }
  next();
}

app.post("/api/reports", async (req, res) => {
  const { reporter, email, location, issue, description, imageData } = req.body || {};
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      !location || !issue || !description) {
    return res.status(400).json({error: "Name, valid email, location, issue and description are required."});
  }
  if (imageData && (!/^data:image\/(png|jpe?g|webp);base64,/i.test(imageData) || imageData.length > 6_800_000)) {
    return res.status(400).json({error: "Image must be PNG, JPG or WebP and under 5 MB."});
  }
  const id = makeId("GC");
  const createdAt = new Date().toISOString();
  const report = {id, reporter: String(reporter || "Citizen").slice(0,120),
    email: String(email).slice(0,254), location: String(location).slice(0,500),
    issue: String(issue).slice(0,200), description: String(description).slice(0,5000),
    imageData: imageData || "", status: "Reported", createdAt};
  db.prepare(`INSERT INTO reports
    (id,reporter,email,location,issue,description,imageData,status,createdAt)
    VALUES (@id,@reporter,@email,@location,@issue,@description,@imageData,@status,@createdAt)`).run(report);

  const summary = `Tracking ID: ${id}\nReporter: ${report.reporter}\nEmail: ${report.email}\nLocation: ${report.location}\nIssue: ${report.issue}\nDescription: ${report.description}\nSubmitted: ${createdAt}\nStatus: Reported`;
  const emailResults = await Promise.allSettled([
    sendMail(report.email, `GangaConnect report received: ${id}`, `Thank you for reporting an issue.\n\n${summary}\n\nUse this tracking ID on the GangaConnect website to check its status.`),
    process.env.ADMIN_EMAIL ? sendMail(process.env.ADMIN_EMAIL, `New GangaConnect report: ${id}`, summary) : Promise.resolve(false)
  ]);
  res.status(201).json({report: {...report, imageData: undefined},
    email: {reporter: emailResults[0].status === "fulfilled" && emailResults[0].value,
            administrator: emailResults[1].status === "fulfilled" && emailResults[1].value}});
});

app.get("/api/reports/:id", (req, res) => {
  const report = db.prepare("SELECT id,reporter,location,issue,description,imageData,status,createdAt FROM reports WHERE id=?")
    .get(req.params.id.toUpperCase());
  if (!report) return res.status(404).json({error: "Report ID not found."});
  res.json({report});
});

app.post("/api/enrollments", async (req, res) => {
  const {name, email, projectName} = req.body || {};
  if (!name || !projectName || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({error: "Name, project and valid email are required."});
  const enrollment = {id: makeId("GCE"), name: String(name).slice(0,120),
    email: String(email).slice(0,254), projectName: String(projectName).slice(0,200),
    createdAt: new Date().toISOString()};
  db.prepare("INSERT INTO enrollments (id,name,email,projectName,createdAt) VALUES (@id,@name,@email,@projectName,@createdAt)").run(enrollment);
  await Promise.allSettled([
    sendMail(enrollment.email, `GangaConnect enrollment: ${enrollment.id}`,
      `Your registration is recorded.\nProject: ${enrollment.projectName}\nEnrollment ID: ${enrollment.id}\n\nA certificate will be available after the organizer confirms your attendance.`),
    process.env.ADMIN_EMAIL ? sendMail(process.env.ADMIN_EMAIL, `New volunteer enrollment: ${enrollment.id}`,
      `Name: ${enrollment.name}\nEmail: ${enrollment.email}\nProject: ${enrollment.projectName}\nEnrollment ID: ${enrollment.id}`) : Promise.resolve(false)
  ]);
  res.status(201).json({enrollment});
});

/* Organizer-only attendance control. Keep ADMIN_TOKEN private. */
app.get("/api/admin/reports", requireAdmin, (req, res) => {
  res.json({reports: db.prepare("SELECT id,reporter,email,location,issue,status,createdAt FROM reports ORDER BY createdAt DESC").all()});
});
app.patch("/api/admin/reports/:id", requireAdmin, (req, res) => {
  const allowed = ["Reported", "Under Verification", "Action in Progress", "Resolved", "Rejected"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({error: "Invalid status."});
  const result = db.prepare("UPDATE reports SET status=? WHERE id=?").run(req.body.status, req.params.id.toUpperCase());
  if (!result.changes) return res.status(404).json({error: "Report not found."});
  res.json({success: true});
});
app.get("/api/admin/enrollments", requireAdmin, (req, res) => {
  res.json({enrollments: db.prepare("SELECT * FROM enrollments ORDER BY createdAt DESC").all()});
});
app.patch("/api/admin/enrollments/:id/attendance", requireAdmin, async (req, res) => {
  const attended = req.body.attended === true;
  const row = db.prepare("SELECT * FROM enrollments WHERE id=?").get(req.params.id.toUpperCase());
  if (!row) return res.status(404).json({error: "Enrollment not found."});
  db.prepare("UPDATE enrollments SET attended=? WHERE id=?").run(attended ? 1 : 0, row.id);
  if (attended) await sendMail(row.email, `Attendance verified: ${row.projectName}`,
    `Your attendance has been verified.\nEnrollment ID: ${row.id}\nYou can now download your certificate from the GangaConnect website.`);
  res.json({success: true, attended});
});

app.get("/api/certificates/:id", (req, res) => {
  const email = String(req.query.email || "").trim().toLowerCase();
  const row = db.prepare("SELECT * FROM enrollments WHERE id=? AND lower(email)=?")
    .get(req.params.id.toUpperCase(), email);
  if (!row) return res.status(404).json({error: "Enrollment ID and email do not match."});
  if (!row.attended) return res.status(403).json({error: "Attendance has not yet been verified by the organizer."});

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename="GangaConnect-${row.id}.pdf"`);
  const pdf = new PDFDocument({size: "A4", margin: 55});
  pdf.pipe(res);
  pdf.rect(25,25,545,790).lineWidth(3).strokeColor("#147d92").stroke();
  pdf.fontSize(28).fillColor("#07566a").text("GangaConnect", {align:"center"});
  pdf.moveDown(0.5).fontSize(15).fillColor("#3fa66a").text("CERTIFICATE OF PARTICIPATION", {align:"center", characterSpacing:1});
  pdf.moveDown(2).fontSize(14).fillColor("#17343d").text("This certificate is proudly presented to", {align:"center"});
  pdf.moveDown(0.7).fontSize(30).fillColor("#07566a").text(row.name, {align:"center"});
  pdf.moveDown(0.7).fontSize(14).fillColor("#17343d").text("for participating in", {align:"center"});
  pdf.moveDown(0.5).fontSize(21).fillColor("#147d92").text(row.projectName, {align:"center"});
  pdf.moveDown(1).fontSize(12).fillColor("#6d858b").text("Thank you for contributing to river conservation and community action.", {align:"center"});
  pdf.moveDown(2).fontSize(10).text(`Enrollment ID: ${row.id}`, {align:"center"});
  pdf.text(`Issued: ${new Date().toLocaleDateString("en-IN")}`, {align:"center"});
  pdf.end();
});

app.post("/api/initiatives", async (req, res) => {
  const {name, email} = req.body || {};
  if (!name || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({error:"Organization name and valid email are required."});
  db.prepare("INSERT INTO initiatives (name,email,createdAt) VALUES (?,?,?)").run(name,email,new Date().toISOString());
  if (process.env.ADMIN_EMAIL) await sendMail(process.env.ADMIN_EMAIL, "New GangaConnect initiative", `Organization: ${name}\nContact: ${email}`);
  res.status(201).json({success:true});
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`GangaConnect running on port ${PORT}`));
